#include <math.h>
#include <allegro.h>
#include <alfont.h>
#include "elib.h"
#include "exptlib.h"
#include <stdlib.h>
#include <stdio.h>

extern ALFONT_FONT *fontlst[];
extern long double rtSlope;
extern int errorTotal;
extern movie *std_m; 
extern image *std_i; 

extern long double rtSlope;
extern int UseDIO24;
#define backup 0
#define STATUS RUN

#define rate 60
//#define fastms 200
#define numletter 10
#define numaddents 2
#define numsums 12
#define WRONG 0
#define RIGHT 1
#define RespTrue 'z';
#define RespFalse '/';

#define numblocks 2
#define numpracblocks 1
#define numtrials 10
#define numpractrials 8

#define xcen 399
#define ycen 299
#define fixtime 30
#define fore_time 30
#define foretime 30

int getaddend(int id);
int getletter(int id);
int getsum(int id);
void rtexit(FILE *outfile);
int numtolet(int);
int numtolet(int);

int main(){
  int cor,randt;
  //int letter,addent,sum;
  int letter[numtrials],addent[numtrials],sum,rand[numtrials];
  int letterp[numpractrials],addentp[numpractrials],randp[numpractrials];
  int i,k;
  int rtwarnings=0;
  char stimstring[6];
  char blockstart[20];

logtype *log;
FILE *outfile;
FILE *backfile;
char outline[80];
//long seed;
 int seed;


//images: fix, blank,target,answer
image *fix,*blank,*target,*answer;
//movie
movie *ques;
response *data;
 float RT;
 int resp,acc;
 double prand=.5;
 int randsign,randvalue;

//from si4

  UseDIO24= 0;
  log=(logtype *)malloc(1*sizeof(logtype));
  initLog(STATUS,log);
  outfile=fopen(log->outfn,"w");

  setup(800,600,800, 600, 0,rate,8,"../../fonts/fonts.lst"); 
  if(alfont_set_font_size(fontlst[1], 28)==ALFONT_ERROR)
    error("Cannot Set Font Size");
 
  seed=log->seed;
 
   makePalette(GRAYSCALE);

  ques=newMovie(3);
  fix=newImage();
  blank=newImage();
  target=newImage();


  for(i=0;i<numpractrials;i++)
    {
      letterp[i]=i+11;
      addentp[i]=((i%2))*2+7;
      randp[i]=(i%3)-1;
    }

  for(k=0;k<numpracblocks;k++)
    {
      runMovieText("practice",xcen,ycen,1,255);

  distribute(letterp,numpractrials,&seed);
  distribute(addentp,numpractrials,&seed);
  distribute(randp,numpractrials,&seed);

  for(i=0;i<numpractrials;i++)
  {  
 sum=letterp[i]+addentp[i]+randp[i];
 if(sum==27) sum=25;

  clearImage(fix);
  clearImage(blank); 


  vline(*fix,xcen,ycen+20,ycen-20,255);
  hline(*fix,xcen-20,ycen,xcen+20,255);

  setMovie(ques,0,fix,fixtime);
  setMovie(ques,1,blank,foretime);


  clearImage(target);
  
sprintf(stimstring,"%c+%d=%c",numtolet(letterp[i]),addentp[i],numtolet(sum));

   drawText(target,stimstring,xcen,ycen,1,253);
   setMovie(ques,2,target,1);
  data=runMovie(ques,UNTIL_RESPONSE,1);

 switch ((data)->x[0].resp & 0x00ff){  
  case 'z': resp=0;break; //wrong
  case 'Z': resp=0;break;
  case '/': resp=1;break; //correct
  case '?': resp=1;break;
  case '@': resp=4;break;
   default: resp=5;break;}

 
  if (resp==4) {cleanup();
  printf ("stopped while running by participant\n");exit(1);}
  
  
  
   if ((ques->x[2].ts)==0) RT=-1; //*RT or RT?
  else  RT=((data)->x[0].rt-ques->x[2].ts)*rtSlope;
  
  if (RT<.2)
    {
      audio(ERROR);
      runMovieTimedText("TOO FAST! WAIT TO CONTINUE",xcen,ycen,1,255,360);
    }

  
  if (resp==5)
    {
      runMovieText("INVALID KEY <reposition hands, hit spacebar to continue>",xcen,ycen,1,255);
    }
  

  if(randp[i]==0) //true value
    {
      if(resp==1) acc=1;
      else acc=0;

    }
  else {
    if(resp==0) acc=1;
    else acc=0;

       }
        
      if(acc==1) audio(CORRECT);
	  else audio(ERROR);    


  fprintf(outfile,"%03d -%02d %02d    %d %c %d   %d %d %c  %d %d %lf\n",
log->subjnum,k,i,letterp[i],numtolet(letterp[i]),addentp[i],randp[i],sum,numtolet(sum),resp,acc,RT);
  }
    
}



	 // random number generation
  
  for(i=0;i<numtrials;i++)
    {
     letter[i]=i+1;
     addent[i]=((i%2))*2+7;
     rand[i]=(i%3)-1;
    }
  

  for(k=0;k<numblocks;k++)
    {
      if(k==0) runMovieText("the first block",xcen,ycen,1,255);
      else {sprintf(blockstart,"Repetition %d",k);
      runMovieText(blockstart,xcen,ycen,1,255);}
      // runMovieText("A new block",xcen,ycen,1,255);

  distribute(letter,numtrials,&seed);
  distribute(addent,numtrials,&seed);
  distribute(rand,numtrials,&seed);

  for(i=0;i<numtrials;i++)
  {  
    //   randsign=gsl_ran_bernoulli (const seed2, prand);
    //   randvalue=gsl_ran_bernoulli (const seed2, prand);

    //rand=(1.0*(.5+randsign/2))*randvalue;
    // rand=randint(-1,1,&seed);
 sum=letter[i]+addent[i]+rand[i];
 if(sum==27) sum=25;
 //sum=letter[i]+addent[i]+rand;

  clearImage(fix);
  clearImage(blank); 


  vline(*fix,xcen,ycen+20,ycen-20,255);
  hline(*fix,xcen-20,ycen,xcen+20,255);

  setMovie(ques,0,fix,fixtime);
  setMovie(ques,1,blank,foretime);


  clearImage(target);
  ///sprintf(stimstring,"%d+%d=%d",letter[i],addent[i],sum);
sprintf(stimstring,"%c+%d=%c",numtolet(letter[i]),addent[i],numtolet(sum));

   //        sprintf(stimstring,"%c+%i=%c",
   //             (char)(numtolet(getletter(alltrials[i]))), getaddend(alltrials[i]), (char)(numtolet(getsum(alltrials[i])))    );

   //runMovieText(stimstring,xcen,ycen,0,255);
   drawText(target,stimstring,xcen,ycen,1,253);
   setMovie(ques,2,target,1);
  data=runMovie(ques,UNTIL_RESPONSE,1);

  
  
 switch ((data)->x[0].resp & 0x00ff){  
  case 'z': resp=0;break; //wrong
  case 'Z': resp=0;break;
  case '/': resp=1;break; //correct
  case '?': resp=1;break;
  case '@': resp=4;break;
   default: resp=5;break;}

 
  if (resp==4) {cleanup();
  printf ("stopped while running by participant\n");exit(1);}
  
  
  
   if ((ques->x[2].ts)==0) RT=-1; //*RT or RT?
  else  RT=((data)->x[0].rt-ques->x[2].ts)*rtSlope;
  
  if (RT<.2)
    {
      audio(ERROR);
      runMovieTimedText("TOO FAST! WAIT TO CONTINUE",xcen,ycen,1,255,360);
    }

  
  if (resp==5)
    {
      runMovieText("INVALID KEY <reposition hands, hit spacebar to continue>",xcen,ycen,1,255);
    }
  

  if(rand[i]==0) //true value
    {
      if(resp==1) acc=1;
      else acc=0;

    }
  else {
    if(resp==0) acc=1;
    else acc=0;

       }
        
      if(acc==1) audio(CORRECT);
	  else audio(ERROR);    



  fprintf(outfile,"%03d %02d %02d    %d %c %d   %d %d %c  %d %d %lf\n",
log->subjnum,k,i,letter[i],numtolet(letter[i]),addent[i],rand[i],sum,numtolet(sum),resp,acc,RT);
  }
    
}

 
fclose(outfile);
//runMovieText(ques->x[2].ts,xcen,ycen,1,255);
  runMovieText("STOP!!! Go back to room 203",xcen,ycen,1,255);
  cleanup();
  
}


int getaddend(int id){
  return 1; //(id%numaddends)+1;
}

int getsum(int id){
 //int temp=floor(floor(id/numaddends)/numletters);
 return 1; //(temp%numsums)+sumone+getletter(id)+getaddend(id);
}

int getletter(int id){
 //int temp=floor(id/numaddends);
 return 1; //(temp%numletters)+1;
}

int numtolet(int id){
return (id+64);
}
