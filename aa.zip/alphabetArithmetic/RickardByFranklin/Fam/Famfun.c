int getaddend(int id){
  return xxx;
}

int getsum(int id){
  return xxx;
}

int getletter(int id){
  return xxx;
}

void rtexit(FILE *outfile){
  image *rtexit_i;
  movie *rtexit_m;
  response *data;
  int code=0;
  rtexit_i=newImage();
  downloadImage(rtexit_i);
  clearPicBuf();
  drawText("You have had 5 too-fast responses.",0,0,0,253);
  drawText("Please see the experimenter.",0,50,0,253);
  uploadImage(rtexit_i);
  rtexit_m=initMovie(1);
  setMovie(rtexit_m,0,rtexit_i,1);
  do
   {
     data=runMovie(rtexit_m, UNTIL_RESPONSE,2);
     if ((data->x[0].resp=='x') && (data->x[1].resp=='@')) code=1;
   } while (code==0);
  fclose(outfile);
  CleanupMoviePackage();
  exit(1);
}
