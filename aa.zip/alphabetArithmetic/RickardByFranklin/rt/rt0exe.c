#include "rt.h"
#include <string.h>

extern ALFONT_FONT *fontlst[];
extern long double rtSlope;
extern int errorTotal;
extern movie *std_m;
extern image *std_i;

#define backup 0
#define STATUS DEBUG

#define rate 60
#define numperblock 10
#define numblock 1
#define numtrials (numperblock*numblock)
#define FONTNUM 1

extern int UseDIO24;

main()
{
  myParameters p;
  //myStemParams myTrial;
  movie *stim_m;
  image **a;
  response *data;
  logtype *log;
  int t,seed,cond;
  int resp; float RT;
  FILE *outfile;

  int add1[numperblock];
  int add2[2];
  int outs[numperblock];
  int tr;
  int a;
  int rep,rep0;
  int code[numperblock];
  add2[1]=7;
  add2[2]=9;

  UseDIO24= 1;
  log=(logtype *)malloc(1*sizeof(logtype));
  initLog(STATUS,log);
  outfile=fopen(log->outfn,"w");
  seed=log->seed;
  p.seed=log->seed;

  setup(800,600,800, 600, 0,rate,8,"../../fonts/fonts.lst");
  if(alfont_set_font_size(fontlst[1], 18)==ALFONT_ERROR)
    error("Cannot Set Font Size");
  makePalette(GRAYSCALE);

  stim_m=newMovie(3);
  a= (image **)malloc(3*sizeof(image *));
  for (t=0;t<3;3++) a[t]=newImage();
  //1, Fix; 2, Blank; 3, Question; 

  p.fixtime=30;
  p.blanktime=30;
  p.showtime=50;
  
  p.xc=399;
  p.yc=299;
  p.tooFast=.2;
  
  p.stimOffset=50;
  


  //myTrial.stim_m=newMovie(1); 
  //myTrial.background_i=newImage();
  //myTrial.stim_i=newImage();


  //p. series

  //myTrial. series

  for (blk=0;blk<numblock;blk++)
  {
    //rep=0;
    //while(rep==0)
    // {
    //rep=1;
	for (a=0; a<numperblock; a++) add1[a]=a+1; 

       distribute (add1,numperblock,&seed);

       //for (a=1; a<=numperblock; a++) 
       //{
       //outs[a]=add1[a]+add2[(a-1)/5+1];
       //for (b=1;b<a;b++)
       //{      
       // if(outs[b]==outs[a]) rep0=0;  
       // else rep0=1;
       //} 
       //rep=rep*rep0;
       // } 
       // }
      

      for(k=0; k<10; k++) code[k]=k+1;
      distribute(code,numperblock,&seed);

      for(k=1; k<=10; k++) 
      {
        add1[k]=add1[code[k]];//code is the actual a;
        add2[k]=add2[(code[k]-1)/5+1];
        outs[k]=outs[code[k]];
      }

      for (tr=0;tr<numperblock;tr++) 
      {
       string=paste(add1[tr+1],"+",add2[tr/5+1]);
       clearImage(a[0]);
       clearImage(a[1]);
       vline(*a[0],p->xc,p->yc+20,p->yc-20,255); 
       hline(*a[0],p->xc-20,p->yc,p->xc+20,255);
       drawText(a[1],add1[1],p->xc,p->yc,1,255);
 
       setMovie(stim_m,0,a[0],fixtime); 

       drawText(a[1],string,p->xc,p->yc,1,255);

       setMovie(stim_m,1,a[1],p->fixtime);

       runMovie(stim_m,FULL_SHOW,0);

       setMovie(stim_m,0,a[1],p->fixtime);
	   
       runMovie(stim_m,UNTIL_RESPONSE,1);
  *data=runMovie(stim_m,UNTIL_RESPONSE,1);
  switch ((*data)->x[0].resp & 0x00ff){ 
  case 'H': *resp=8;break;
  case 'h':  *resp=8;break;
  case 'I': *resp=9;break;
  case 'i':  *resp=9;break;
  case 'J': *resp=10;break;
  case 'j':  *resp=10;break;
  case 'K': *resp=11;break;
  case 'k':  *resp=11;break;
  case 'L': *resp=12;break;
  case 'l':  *resp=12;break;
  case 'M': *resp=13;break;
  case 'm':  *resp=13;break;
  case 'N': *resp=14;break;
  case 'n':  *resp=14;break;
  case 'O': *resp=15;break;
  case 'o':  *resp=15;break;
  case 'P': *resp=16;break;
  case 'p':  *resp=16;break;
  case 'Q': *resp=17;break;
  case 'q':  *resp=17;break;
  case 'R': *resp=18;break;
  case 'r':  *resp=18;break;
  case 'S': *resp=19;break;
  case 's':  *resp=19;break;
  case 'T': *resp=20;break;
  case 't':  *resp=20;break;
  case 'U': *resp=21;break;
  case 'u':  *resp=21;break;  
  case 'V': *resp=22;break;
  case 'v':  *resp=22;break;
  case 'W': *resp=23;break;
  case 'w':  *resp=23;break;
  case 'X': *resp=24;break;
  case 'x':  *resp=24;break;
  case 'Y': *resp=25;break;
  case 'y':  *resp=25;break;
  case 'Z': *resp=26;break;
  case 'z':  *resp=26;break;
  case '@': *resp=2;break;
  default: *resp=3;break;}

  if (*resp==2) {cleanup();
  printf ("stopped while running by participant\n");exit(1);}
  if ((stim_m->x[1].ts)==0) *RT=-1;
  else *RT=((*data)->x[0].rt-stim_m->x[1].ts)*rtSlope;
  if (*RT<p->tooFast)
    {
      audio(ERROR);
      runMovieTimedText("TOO FAST! WAIT TO CONTINUE",p->xcen,p->ycen,1,255,360);
    }
   else
    {
      if (p->stimCol==*resp) audio(CORRECT);
	else audio(ERROR);
    }
 

  if (*resp==3)
    {
      runMovieText("INVALID KEY <reposition hands, hit spacebar to continue>",p->xcen,p->ycen,1,255);
    }

  if(resp==outs[tr+1]) acc=1;
  else acc=2;

  stemComplete(&myTrial);//? 
	   
	
	       fprintf(outfile,"%02d %02d %02d %02d %02d %01d %02d %02d %01d %+f %d\n",log->subjnum,blk,a,code,add1[tr],add2[tr],outs[tr],resp,acc,RT, errorTotal);
	


      }//trial
  }//block

 runMovieText("STOP!!! Go back to room 203",p.xc,p.yc,1,3);
 cleanup();
 fclose(outfile);


}
