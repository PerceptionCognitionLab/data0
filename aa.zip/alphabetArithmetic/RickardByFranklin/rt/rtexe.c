#include "rt.h"
#include <string.h>

extern ALFONT_FONT *fontlst[];
extern long double rtSlope;
extern int errorTotal;
extern movie *std_m;
extern image *std_i;

#define backup 0
#define STATUS DEBUG

#define rate 60
#define numperblock 10
#define numblock 1
#define numtrials (numperblock*numblock)
#define FONTNUM 1

extern int UseDIO24;


main()
{
  myParameters p;
  //myStemParams myTrial;
  movie *stim_m;
  image **a;
  response *data;
  logtype *log;
  int t,seed,cond,blk,i;
  int acc,tf,err,np;
  int resp; float RT;
  FILE *outfile;

  int add1[numperblock];
  int add2;
  int error;
  int outs[numperblock];
  int rep,rep0;
  int code[numperblock];
  int a2type;
  char let[26]={'a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z'};


  UseDIO24= 1;
  log=(logtype *)malloc(1*sizeof(logtype));
  initLog(STATUS,log);
  outfile=fopen(log->outfn,"w");
  seed=log->seed;
  p.seed=log->seed;

  setup(800,600,800, 600, 0,rate,8,"../../fonts/fonts.lst");
  //if(alfont_set_font_size(fontlst[1], 18)==ALFONT_ERROR)
  //error("Cannot Set Font Size");
  makePalette(GRAYSCALE);

  stim_m=newMovie(4);
  a= (image **)malloc(4*sizeof(image *));
  for (t=0;t<3;t++) a[t]=newImage();
  //1, Fix; 2, Blank; 3, Question; 

  p.fixtime=30;
  p.blanktime=30;
  p.showtime=50;
  
  p.xc=399;
  p.yc=299;
  p.tooFast=.2;
  
  
  for (blk=0;blk<numblock;blk++)
  {
    //code 
    for (i=0; i<numperblock; i++) code[i]=i%10;
    distribute(code,numperblock,&seed);

    for (t=0;t<numperblock;t++)
	{       
       add1[t]=code[t]+8; 
       //add2
       a2type=rand()%2;
       add2=(a2type+(code[t]%2)-2*a2type*(code[t]%2))*2+7;
       
       // outs
       // Is the counterbalance right?
       err=rand()%2;
       np=rand()%2;
       np=-1+2*np;
       outs[t]=code[t]+8+add2+err*np;
    


	  //initTrials(stim_m,a,&p);

       //sprintf(p.question, "%d %d %d",1,2,3);
       sprintf(p.question,"%c %c %c %c %c", let[add1[t]],'+',add2, '=', let[outs[t]]); 
	  runQ(stim_m,a,&p,&data,&resp,&RT);

          if(add1[t]+add2==outs[t]) tf=1;
          else tf=0;
     
          if(resp==tf) acc=1;
          else acc=0;
	  
	  fprintf(outfile,"%02d %02d %02d %02d %02d %01d %02d %01d %01d %01d %+f %d\n",log->subjnum,blk,a,code,add1[t],add2,outs[t],a2type,tf,acc,RT, errorTotal);	  
	    
	 }
    }         
  runMovieText("STOP!!! Go back to room 203",p.xc,p.yc,1,255);
  cleanup();
  fclose(outfile);
  
}
