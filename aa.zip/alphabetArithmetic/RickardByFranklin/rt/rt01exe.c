#include "rt.h"
#include <string.h>

extern ALFONT_FONT *fontlst[];
extern long double rtSlope;
extern int errorTotal;
extern movie *std_m;
extern image *std_i;

#define backup 0
#define STATUS DEBUG

#define rate 60
#define numperblock 10
#define numblock 1
#define numtrials (numperblock*numblock)
#define FONTNUM 1

extern int UseDIO24;


main()
{
  myParameters p;
  //myStemParams myTrial;
  movie *stim_m;
  image **a;
  response *data;
  logtype *log;
  int t,seed,cond,blk,i;
  int acc;
  int resp; float RT;
  FILE *outfile;

  int add1[numperblock];
  int add2[2];
  int error;
  int outs[numperblock];
  int rep,rep0;
  int code[numperblock];
  add2[1]=7;
  add2[2]=9;

  UseDIO24= 1;
  log=(logtype *)malloc(1*sizeof(logtype));
  initLog(STATUS,log);
  outfile=fopen(log->outfn,"w");
  seed=log->seed;
  p.seed=log->seed;

  setup(800,600,800, 600, 0,rate,8,"../../fonts/fonts.lst");
  if(alfont_set_font_size(fontlst[1], 18)==ALFONT_ERROR)
    error("Cannot Set Font Size");
  makePalette(GRAYSCALE);

  stim_m=newMovie(4);
  a= (image **)malloc(4*sizeof(image *));
  for (t=0;t<3;t++) a[t]=newImage();
  //1, Fix; 2, Blank; 3, Question; 

  p.fixtime=30;
  p.blanktime=30;
  p.showtime=50;
  
  p.xc=399;
  p.yc=299;
  p.tooFast=.2;
  
  
  for (blk=0;blk<numblock;blk++)
  {
	for (i=0; i<numperblock; i++) add1[i]=i+1; 

       distribute (add1,numperblock,&seed);
       //add2
       
       // outs
       
       for (i=0; i<numperblock; i++)
	 {
          add2[i]=add2[(code[i]-1)/5+1];
          //randit? 
	  error=randit(-1,1,seed)
          outs[i]=add1[i]+add2[i]+error
	    }

       // correct

       // wrong 
 
      

      for (t=0;t<numperblock;t++)
	{
	  //initTrials(stim_m,a,&p);
          sprintf(p.question,"%d %d %d %d %d", 32+add1[t],11,add2[t], 29, 32+outs[t]); 
	  runQ(stim_m,a,&p,&data,&resp,&RT);
	  
	  fprintf(outfile,"%02d %02d %02d %02d %02d %01d %02d %02d %01d %+f %d\n",log->subjnum,blk,a,code,add1[t],add2[t],outs[t],resp,acc,RT, errorTotal);	  
	    
	 }
    }         
  runMovieText("STOP!!! Go back to room 203",p.xc,p.yc,1,255);
  cleanup();
  fclose(outfile);
  
}
