#include <allegro.h>
#include <alfont.h>
#include "elib.h"
#include "exptlib.h"
#include <stdlib.h>
#include <stdio.h>

typedef struct
{
  
  int fixtime,blanktime,showtime;
  int xc,yc,tooFast;
  double seed;
  char question[12];
  //question?
} myParameters;

void initTrials(movie *stim_m,image **a,myParameters *p);
void runQ(movie *stim_m, image **a, myParameters *p, response **data, int *resp, float *RT);
void runA(movie *stim_m, image **a, myParameters *p, response **data, int *resp, float *RT);
