#include <allegro.h>
#include <alfont.h>
#include "elib.h"
#include "exptlib.h"
#include <stdlib.h>
#include <stdio.h>

extern ALFONT_FONT *fontlst[];
extern long double rtSlope;
extern int errorTotal;
extern movie *std_m;

#define MAXCHAR 7
#define NUMFILLERS 16
#define NUMTARGETS 32

#define backup 0
#define STATUS DEBUG

#define rate 60
#define numperblock 10
#define numblock 1 //58
#define numtrials (numperblock*numblock)
#define FONTNUM 1

extern int UseDIO24;

main()
{
  int fixtime=30;
  int blanktime=30;
  int targettime=30;
  int xc=399;
  int yc=299;
  int tooFast=.2;
  int stimOffset=100;
  int accN=0;

  movie *stim_m;
  image **a;
  int t,seed,cond;
  reponse *data;
  int resp; float RT;
  logtype *log;
  FILE *outfile;

  int add1[numperblock];
  int add2[2];
  int outs[numperblock];
  int tr;
  int a;
  int rep,rep0;
  int code[numperblock];
  add2[1]=7;
  add2[2]=9;

  UseDIO24 = 1;
  log=(logtype *)malloc(1*sizeof(logtype));  //?
  initLog(STATUS,log);
  outfile=fopen(log->outfn,"w");
  seed=log->seed;

  setup(800,600,800, 600, 0,rate,8,"../../fonts/fonts.lst");
  if(alfont_set_font_size(fontlst[1], 18)==ALFONT_ERROR)
    error("Cannot Set Font Size");
    
  makePalette(GRAYSCALE);
  Palette[0]=colVal(0,0,0); //black
  Palette[1]=colVal(255,255,255);  //white
  

  stim_m=newMovie(3);
  a= (image **)malloc(3*sizeof(image *));
  for (t=0;t<3;t++) a[t]=newImage(); 

  setMovie(stim_m,0,a[0],30);
  setMovie(stim_m,1,a[1],30);
  setMovie(stim_m,2,a[2],1);
  // setMovie(stim_m2,0,a[1],30);
  // setMovie(stim_m2,1,a[3],30);
    
  for (blk=0;blk<numblock;blk++)
  {
      rep=0;
      while(rep==0)
      {
	rep=1;
       distribute (add1,numperblock,&seed);
       for (a=1; a<=10; a++) 
       {
        outs[a]=add1[a]+add2[(a-1)/5+1];
        for (b=1;b<a;b++)
	{  
          if(outs[b]==outs[a]) rep0=0;  
          else rep0=1;
        } // check repetition
        rep=rep*rep0;
       } // assigning 10 add1s
      }//whether rerun; if not, add1 and outs decided
          

      for(k=1; k<=10; k++) code[k-1]=k;
      distribute(code,numperblock,&seed);
      for(k=1; k<=10; k++) // for(k=0; k<10; k++)?
      {
        add1[k]=add1[code[k]];//code is the actual a;
        add2[k]=add2[(code[k]-1)/5+1];
        outs[k]=outs[code[k]];
      }

      for (tr=0;tr<numperblock;tr++) 
      {
      data=runMovie(trial,UNTIL_RESPONSE,1);
       
       string=paste(add1[tr+1],"+",add2[tr/5+1]);
       clearImage(a[0]);
       clearImage(a[1]);
       vline(*a[0],p->xc,p->yc+20,p->yc-20,255); 
       hline(*a[0],p->xc-20,p->yc,p->xc+20,255);
       drawText(a[1],add1[1],p->xc,p->yc,1,255);

       sprintf(a[1],,"%d %d %d %d %d %d %d", codee[1],codee[2],codee[3],codee[4],codee[5],codee[6],codee[7]) ;

 
       setMovie(stim_m,0,a[0],fixtime); 

       drawText(a[1],string,p->xc,p->yc,1,255);

       setMovie(stim_m,1,a[1],p->fixtime);

       runMovie(stim_m,FULL_SHOW,0);

       setMovie(stim_m,0,a[1],p->fixtime);
	   
       runMovie(stim_m,UNTIL_RESPONSE,1);

       *data=runMovie(stim_m,UNTIL_RESPONSE,1);
      }//trial
  }//block

 runMovieText("STOP!!! Go back to room 203",p.xc,p.yc,1,3);
 cleanup();
 fclose(outfile);


}
