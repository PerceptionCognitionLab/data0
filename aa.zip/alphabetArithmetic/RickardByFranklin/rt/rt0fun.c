
#include "rt.h" 
#include "math.h"

extern long double rtSlope; 


void initTrials(movie *stim_m, image **a, myParameters *p)
{

   clearImage(a[0]); 
   clearImage(a[1]);
   vline(*a[0],p->xc,p->yc+20,p->yc-20,255); 
   hline(*a[0],p->xc-20,p->yc,p->xc+20,255);
   
   setMovie(stim_m,0,a[0],p->fixtime); 
   setMovie(stim_m,0,a[1],p->fixtime);
}

void runQ(movie *stim_m, image **a, myParameters *p,response **data, int *resp, float *RT)
{
  clearImage(a[2]);
  setMovie(stim_m,0,a[2],p->fixtime);  
  drawText(a[2],p->nsstring,p->xc,p->yc,1,255); 
  runMovie(stim_m,FULL_SHOW,0);
  setMovie(stim_m,1,a[2],p->fixtime);
 runMovie(stim_m,UNTIL_RESPONSE,1); 
}

void runA(movie *stim_m, image **a, myParameters *p,response **data, int *resp)
{
   clearImage(a[3]); 
   setMovie(stim_m,0,a[3],p->fixtime);
   drawText(a[3],p->nsstring,p->xc,p->yc,1,255);
   runMovie(stim_m,FULL_SHOW,0);
  setMovie(stim_m,1,a[3],p->fixtime);
 runMovie(stim_m,UNTIL_RESPONSE,1); 

  *data=runMovie(stim_m,UNTIL_RESPONSE,1);
  switch ((*data)->x[0].resp & 0x00ff){ 
  case 'H': *resp=8;break;
  case 'h':  *resp=8;break;
  case 'I': *resp=9;break;
  case 'i':  *resp=9;break;
  case 'J': *resp=10;break;
  case 'j':  *resp=10;break;
  case 'K': *resp=11;break;
  case 'k':  *resp=11;break;
  case 'L': *resp=12;break;
  case 'l':  *resp=12;break;
  case 'M': *resp=13;break;
  case 'm':  *resp=13;break;
  case 'N': *resp=14;break;
  case 'n':  *resp=14;break;
  case 'O': *resp=15;break;
  case 'o':  *resp=15;break;
  case 'P': *resp=16;break;
  case 'p':  *resp=16;break;
  case 'Q': *resp=17;break;
  case 'q':  *resp=17;break;
  case 'R': *resp=18;break;
  case 'r':  *resp=18;break;
  case 'S': *resp=19;break;
  case 's':  *resp=19;break;
  case 'T': *resp=20;break;
  case 't':  *resp=20;break;
  case 'U': *resp=21;break;
  case 'u':  *resp=21;break;  
  case 'V': *resp=22;break;
  case 'v':  *resp=22;break;
  case 'W': *resp=23;break;
  case 'w':  *resp=23;break;
  case 'X': *resp=24;break;
  case 'x':  *resp=24;break;
  case 'Y': *resp=25;break;
  case 'y':  *resp=25;break;
  case 'Z': *resp=26;break;
  case 'z':  *resp=26;break;
  case '@': *resp=2;break;
  default: *resp=3;break;}

  if (*resp==2) {cleanup();
  printf ("stopped while running by participant\n");exit(1);}
  if ((stim_m->x[2].ts)==0) *RT=-1;
  else *RT=((*data)->x[0].rt-stim_m->x[2].ts)*rtSlope;
  if (*RT<p->tooFast)
    {
      audio(ERROR);
      runMovieTimedText("TOO FAST! WAIT TO CONTINUE",p->xc,p->yc,1,255,360);
    }
  else
    {
      if (p->stimDir==*resp) audio(CORRECT);
      else audio(ERROR);
    }

  if (*resp==3)
    {
      runMovieText("INVALID KEY <reposition hands, hit spacebar to continue>",p->xc,p->yc,1,255);
    }
  //self-made
  if(resp==outs[tr+1]) acc=1;
  else acc=2;


}   



