#include "rt.h" 
#include "math.h"

extern long double rtSlope; 


void runQ(movie *stim_m, image **a, myParameters *p,response **data, int *resp, float *RT)
{
 clearImage(a[0]); 
 clearImage(a[1]);
 vline(*a[0],p->xc,p->yc+20,p->yc-20,255); 
 hline(*a[0],p->xc-20,p->yc,p->xc+20,255);
   
 setMovie(stim_m,0,a[0],p->fixtime); 
 setMovie(stim_m,1,a[1],p->blanktime);

  clearImage(a[2]);

  drawText(a[2],p->question,p->xc,p->yc,1,255); 

   setMovie(stim_m,2,a[2],p->fixtime);

   // runMovie(stim_m,FULL_SHOW,0);
   //setMovie(stim_m,3,a[2],1);

  *data=runMovie(stim_m,UNTIL_RESPONSE,1);
  switch ((*data)->x[0].resp & 0x00ff){
  case 'z': *resp=0;break;
  case 'Z': *resp=0;break;
  case '/': *resp=1;break;
  case '?': *resp=1;break;
  case '@': *resp=2;break;
  default: *resp=3;break;}

  if (*resp==2) {cleanup();
  printf ("stopped while running by participant\n");exit(1);}
  if ((stim_m->x[2].ts)==0) *RT=-1;
  else *RT=((*data)->x[0].rt-stim_m->x[2].ts)*rtSlope;
  if (*RT<p->tooFast)
    {
      audio(ERROR);
      runMovieTimedText("TOO FAST! WAIT TO CONTINUE",p->xc,p->yc,1,255,360);
    }
  else
    {
      //if (p->stimDir==*resp) audio(CORRECT);
      //else audio(ERROR);
    }

  if (*resp==3)
    {
      runMovieText("INVALID KEY <reposition hands, hit spacebar to continue>",p->xc,p->yc,1,255);
    }
}


//problems: font too small; letters not presented yet; frozen in the first trial.
//check: runMovie, setMovie, drawText.
