#include <stdio.h>       
#include <stdlib.h>
#include <string.h> /*for memcpy command*/
#include "movieobj.h"
#include "video.h"
#include <mem.h>
#include "exptlib.h"
#include <math.h>

#define status DEBUG
#define fastms 200
#define numlet 10
#define numadd 2
#define numsumerr 3
#define WRONG 0
#define RIGHT 1
#define RESPTRUE 'z'
#define RESPFALSE '/'
#define numrep 50
#define numtrials (numlet*numrep)
#define numstimuli (numlet*numadd*numsum)
#define sumone (int)(1-(floor(numsumerr/2)+1))

#define fixtime 30
#define blanktime 30

/////////////////

//#define backup 0
//#define STATUS DEBUG
#define rate 60
#define FONTNUM 1
#define numblock 50
#define numperblock numlet

extern ALFONT_FONT *fontlst[];
extern long double rtSlope;
extern int errorTotal;
extern movie *std_m;
extern image *std_i;

extern int UseDIO24;

/////////////////

//functions
int checksum(int sum[]);
char *convertid(int id);
int testtrue(int id);

//check them, change them
int main(){
  double r; //?
  int allstim[numstimuli]; //?
  int i=0,j=0,k=0,problem=0; //i,j,k?
  int blk;
 int alltrials[numperblock];
 char *stimulus;
 char stimstring[5]; 
 int sum[numlet];
 int cor;
 int rand;
 int rtwarnings=0;
 int addent[numlet];

 int xc=399;
 int yc=299;
 
 logtype *log;
 FILE *outfile,*backfile;
 char *fontlist,junk[3]; //what?
 char backstr[40],outline[80]; //what are these?
 long seed; 
 
 image *fix_i,*blank_i,*targ_i,*stim_i;*wrong_i;
 image *fast_i;
 movie *fast_m;
 movie *fix_m,*ready_m,*stim_m,*feed_m;
 
 response **data,*data2; int *resp,second; long *RT;

 //different than later programs?
  fontlist=getenv("FONTLIST");
  log=(logtype *)malloc(1*sizeof(logtype));
  gen_init(status,log);
  SetupMoviePackage(fontlist);
  seed=log->seed;
  outfile=fopen(log->outfn,"wt");

  makePalette(GRAYSCALE);
  //enough?

  fix_i=newImage();
  blank_i=newImage();
  downloadImage(fix_i);
  vline(*fix_i,xc,yc+20,yc-20,255); 
  hline(*fix_i,xc-20,yc,xc+20,255);
  uploadImage(fix_i);
  fix_m=initMovie(1);
  setMovie(fix_m,0,fix_i,30);

  fast_i=newImage();
  downloadImage(fast_i);
  drawText("Too fast",xc,yc,0,1); //what are 0,0,0? 1 right?
  uploadImage(fast_i);
  fast_m=initMovie(1);
  setMovie(fast_m,0,fast_i,1);

  wrong_i=newImage();
  downloadImage(wrong_i);
  drawText("invalid key",xc,yc,0,1); // 1 right?
  uploadImage(wrong_i);
  wrong_m=initMovie(1);
  setMovie(wrong_m,0,wrong_i,1);

  //set initial values of check functions
  
  for(i in 1:floor(numperblock/2))
    {
      addent[i]=7;
    }
    for(i in floor(numperblock/2):numperblock)
      {
	addent[i]=9;
      }

  while(!(checksum(sum))){
    distribute(addent,numperblock,&seed); //addent[1] w.50% =7 or w.100% =7?
    for(i=0;i<numlet;i++){
      sumerr=randint(-1,1,&seed); //the range of randint?
      sum[i]=i+addent[i]+sumerr;
	}
  }
  
  for (blk=0;blk<numblock;blk++)
  {

    for(i=0;i<numperblock;i++){
      alltrials[i]=i;
    }

  //mix the distribute: alltrials->numtrials
 distribute(alltrials,numperblock, &seed);


  stim_m=initMovie(2);
  blank_i=newImage();
  stim_i=newImage();
  setMovie(stim_m,0,blank_i,blanktime);
 
  //start running trials
  runMovie(ready_m,UNTIL_RESPONSE,1);
  for(i=0;i<numperblock;i++){
    stimulus=convertid(alltrials[i]);
		       sprintf(stimstring,"%c%c%c%c%c",stimulus[0],stimulus[1],stimulus[2],stimulus[3],stimulus[4]);

  downloadImage(stim_i);
  clearPicBuf();
  drawText(stimstring,xc-30,yc-30,0,1);
  uploadImage(stim_i);
  setMovie(stim_m,1,stim_i,1);
          
     *data=runMovie(stim_m, UNTIL_RESPONSE,1);

            switch ((*data)->x[0].resp & 0x00ff){
          case RESPTRUE: *resp=1;break;
          case RESPFALSE: *resp=0;break;
          case '@': *resp=2;break;
	  default : *resp=3;break;} // wrong_m?
          RT=data->x[0].rt-(msperframe*fore_time);

          if (*resp==testtrue(alltrials[i]))
            {
            audio(CORRECT);
            cor=1;
           }
         else
            {
              audio(ERROR);
              cor=0;
            }  
          if (*resp==2) {
	    cleanup();
	    //fclose(outfile);CleanupMoviePackage(); 
          printf ("stopped while running by participant\n");exit(1);}

  if ((stim_m->x[2].ts)==0) *RT=-1;
  else *RT=((*data)->x[0].rt-stim_m->x[2].ts)*rtSlope;
  if (*RT<p->tooFast)
    {
      audio(ERROR);
      runMovieTimedText("TOO FAST! WAIT TO CONTINUE",p->xc,p->yc,1,255,360);
    }

  if (*resp==3)
    {
      runMovieText("INVALID KEY <reposition hands, hit spacebar to continue>",p->xc,p->yc,1,255);
    }
}

  fprintf(outline, "sub%03d trl%03d let%i add%i sum%03i id%04d tru%i isr%i %04i rsp%i %i %05d\n",
	  log->subjnum,blk,i,letter[i],addent[i],sum[i],

       log->subjnum, i, getletter(alltrials[i]), getaddend(alltrials[i]),
       getsum(alltrials[i]), alltrials[i], testtrue(alltrials[i]), testrepeat(alltrials[i],repeatedstimuli),stimcounter[alltrials[i]],resp,cor,RT);
fprintf(outfile,"%s",outline);  

if (RT<fastms){
  rtwarnings++;
  audio(INVALID, fast_m);
  if (rtwarnings>=5) rtexit(outfile);
}

}
 //cleanup
 fclose(outfile);
 thankyou();
 CleanupMoviePackage();
 return 0;
}

char * convertid(int id){
 char stimulus[]="L+N=S";
 int addend;
 int temp;
 int letter;
 int sum;
 char charletter;
 char charsum; 
 letter=id+1;
 addend=addent[id]
 sum=sum[id]
 charletter=(letter+64);
 charsum=(letter+addend+sum+64);
 sprintf(stimulus,"%c+%i=%c",charletter,addend,charsum);
 return stimulus;
}


int checksum(int sum[]){
 int i=0,j=0;
 int problem=0; 
 for (i=0;i<numlet;i++){
        for (j=0;j<numlet;j++){
	  if ((j!=i)&&(sum[i]==sum[j])) problem=1; //sum vs.sum or sumTr vs.sumTr?
        }
 }

 if (problem) {return 0;} else{return 1;}  //as long as there are overlaps,(0)
}

int testtrue(int id){
  return (!(sum[id])); //right?
} 

int 
