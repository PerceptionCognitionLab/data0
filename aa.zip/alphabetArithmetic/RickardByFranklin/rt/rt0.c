#include <allegro.h>
#include <alfont.h>
#include "elib.h"
#include "exptlib.h"
#include <stdlib.h>
#include <stdio.h>

#define MAXCHAR 7
#define NUMFILLERS 16
#define NUMTARGETS 32

typedef struct
{
  
  int fixtime,blanktime,targettime;
  int vert,xc,yc,avert,ahoriz,tooFast;
  int xcen, ycen,stimHeight,stimWidth,totPix;
  int stimpos,stimnum,boxsize,boxspread;
  int stimCol,stimPos,stimOffset;
  int pixDist[10000];
  int prime1,prime2,prime3,prime4,prime5,prime6,prime7,target,ans;
  int prime;
  int bw1,bw2,bw3,bw4,bw5,bw6;
  char string[7];

} myParameters; //(siPars)


typedef struct
{
movie *stim_m;
image *background_i, *stim_i;
char *stem;
  int sep, maxInput, x, y, fontnum,include,xc,yc;
  int Result2,null;
response *data;
char input[MAXCHAR+1];
} myStemParams;

 fixtime=30;
 blanktime=30;
 targettime=30;
xc=399;
yc=299;
tooFast=.2;

stimOffset=100; //why?
accN=0;

//myTrial.x=p.xc;
//myTrial.y=p.yc;
//myTrial.xc=p.xc;
//myTrial.yc=p.yc;
//myTrial.stem=stem;
//myTrial.sep=1;
//myTrial.data=data;
//myTrial.maxInput=7;//??  
//myTrial.fontnum=FONTNUM;


///// h /////

//#include "DS.H" 

// extern ALFONT_FONT *fontlst[];
// extern long double rtSlope;
// extern int errorTotal;
// extern movie *std_m;
// extern image *std_i;

// extern long double rtSlope; 


#define backup 0
#define STATUS DEBUG

#define rate 60
#define numperblock 10
#define numblock 1 //58
#define numtrials (numperblock*numblock)
#define FONTNUM 1

//int colVal(int red,int green,int blue); 
                                                                                 


extern int UseDIO24;

main()
{
  myParameters p; 
  myStemParams myTrial; 
  movie *stim_m;
  image **a;
  int t,seed,cond;
  reponse *data;
  int resp; float RT;
  logtype *log;
  FILE *outfile;

  int add1[numperblock];
  int add2[2];
  int outs[numperblock];
  int tr;
  int a;
  int rep,rep0;
  int code[numperblock];
  add2[1]=7;
  add2[2]=9;

  UseDIO24 = 1;
  log=(logtype *)malloc(1*sizeof(logtype));  //?
  initLog(STATUS,log);
  outfile=fopen(log->outfn,"w");
  seed=log->seed;

  setup(800,600,800, 600, 0,rate,8,"../../fonts/fonts.lst");
  if(alfont_set_font_size(fontlst[1], 18)==ALFONT_ERROR)
    error("Cannot Set Font Size");
    makePalette(GRAYSCALE);
  Palette[0]=colVal(0,0,0); //black
  Palette[1]=colVal(255,255,255);  //white

  stim_m=newMovie(2);
  a= (image **)malloc(2*sizeof(image *));
  for (t=0;t<2;t++) a[t]=newImage(); 
    
  // STEP1: randomly add 7 to the first 5 add1, and add 9 to the last 5 add1;
  //STEP2: assign add1 to 10 letters randomly
  //STEP3: If there's any repeation in 10 outs, redo STEP1 and STEP2
  
  for (blk=0;blk<numblock;blk++)
  {
      rep=0;
      while(rep==0)
      {
	rep=1;
       distribute (add1,numperblock,&seed);
       for (a=1; a<=10; a++) 
       {
        outs[a]=add1[a]+add2[(a-1)/5+1];
        for (b=1;b<a;b++)
	{  
          if(outs[b]==outs[a]) rep0=0;  
          else rep0=1;
        } // check repetition
        rep=rep*rep0;
       } // assigning 10 add1s
      }//whether rerun; if not, add1 and outs decided
     // display add1 and outs;

      //randomize the display order
      for(k=1; k<=10; k++) code[k-1]=k;
      distribute(code,numperblock,&seed);
      for(k=1; k<=10; k++) // for(k=0; k<10; k++)?
      {
        add1[k]=add1[code[k]];//code is the actual a;
        add2[k]=add2[(code[k]-1)/5+1];
        outs[k]=outs[code[k]];
      }

      for (tr=0;tr<numperblock;tr++) 
      {
       string=paste(add1[tr+1],"+",add2[tr/5+1]);
       clearImage(a[0]);
       clearImage(a[1]);
       vline(*a[0],p->xc,p->yc+20,p->yc-20,255); 
       hline(*a[0],p->xc-20,p->yc,p->xc+20,255);
       drawText(a[1],add1[1],p->xc,p->yc,1,255);
 
       setMovie(stim_m,0,a[0],fixtime); 

       drawText(a[1],string,p->xc,p->yc,1,255);

       setMovie(stim_m,1,a[1],p->fixtime);

       runMovie(stim_m,FULL_SHOW,0);

       setMovie(stim_m,0,a[1],p->fixtime);
	   
       runMovie(stim_m,UNTIL_RESPONSE,1);

      // getting response, check it;
  *data=runMovie(stim_m,UNTIL_RESPONSE,1);
  switch ((*data)->x[0].resp & 0x00ff){ 
  case 'H': *resp=8;break;
  case 'h':  *resp=8;break;
  case 'I': *resp=9;break;
  case 'i':  *resp=9;break;
  case 'J': *resp=10;break;
  case 'j':  *resp=10;break;
  case 'K': *resp=11;break;
  case 'k':  *resp=11;break;
  case 'L': *resp=12;break;
  case 'l':  *resp=12;break;
  case 'M': *resp=13;break;
  case 'm':  *resp=13;break;
  case 'N': *resp=14;break;
  case 'n':  *resp=14;break;
  case 'O': *resp=15;break;
  case 'o':  *resp=15;break;
  case 'P': *resp=16;break;
  case 'p':  *resp=16;break;
  case 'Q': *resp=17;break;
  case 'q':  *resp=17;break;
  case 'R': *resp=18;break;
  case 'r':  *resp=18;break;
  case 'S': *resp=19;break;
  case 's':  *resp=19;break;
  case 'T': *resp=20;break;
  case 't':  *resp=20;break;
  case 'U': *resp=21;break;
  case 'u':  *resp=21;break;  
  case 'V': *resp=22;break;
  case 'v':  *resp=22;break;
  case 'W': *resp=23;break;
  case 'w':  *resp=23;break;
  case 'X': *resp=24;break;
  case 'x':  *resp=24;break;
  case 'Y': *resp=25;break;
  case 'y':  *resp=25;break;
  case 'Z': *resp=26;break;
  case 'z':  *resp=26;break;
  case '@': *resp=2;break;
  default: *resp=3;break;}

  if (*resp==2) {cleanup();
  printf ("stopped while running by participant\n");exit(1);}
  if ((stim_m->x[1].ts)==0) *RT=-1;
  else *RT=((*data)->x[0].rt-stim_m->x[1].ts)*rtSlope;
  if (*RT<p->tooFast)
    {
      audio(ERROR);
      runMovieTimedText("TOO FAST! WAIT TO CONTINUE",p->xcen,p->ycen,1,255,360);
    }
   else
    {
      if (p->stimCol==*resp) audio(CORRECT);
	else audio(ERROR);
    }
 

  if (*resp==3)
    {
      runMovieText("INVALID KEY <reposition hands, hit spacebar to continue>",p->xcen,p->ycen,1,255);
    }

  if(resp==outs[tr+1]) acc=1;
  else acc=2;

  stemComplete(&myTrial);//? 
	   
	
	       fprintf(outfile,"%02d %02d %02d %02d %02d %01d %02d %02d %01d %+f %d\n",log->subjnum,blk,a,code,add1[tr],add2[tr],outs[tr],resp,acc,RT, errorTotal);
	


      }//trial
  }//block

 runMovieText("STOP!!! Go back to room 203",p.xc,p.yc,1,3);
 cleanup();
 fclose(outfile);


}
