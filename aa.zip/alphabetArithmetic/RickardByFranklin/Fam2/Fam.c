#include <math.h>
#include <allegro.h>
#include <alfont.h>
#include "elib.h"
#include "exptlib.h"
#include <stdlib.h>
#include <stdio.h>

extern ALFONT_FONT *fontlst[];
extern long double rtSlope;
extern int errorTotal;
extern movie *std_m; 
extern image *std_i; 

extern long double rtSlope;
extern int UseDIO24;
#define backup 0
#define STATUS RUN

#define rate 60
//#define fastms 200
#define numletter 10
#define numaddents 2
#define numsums 12
#define WRONG 0
#define RIGHT 1
#define RespTrue 'z';
#define RespFalse '/';

#define numblocks 60
#define numpracblocks 4
#define numtrials 10
#define numpractrials 8

#define xcen 399
#define ycen 299
#define fixtime 30
#define fore_time 30
#define foretime 30

int getaddend(int id);
int getletter(int id);
int getsum(int id);
void rtexit(FILE *outfile);
int numtolet(int);
int numtolet(int);

int main(){
  int cor,randt;
  //int letter,addent,sum;
  int letter[numtrials],addent[numtrials],sum,rand[numtrials],ax[numtrials],ax1[(numtrials)/2],ax2[(numtrials)/2];
  int letterp[numpractrials],addentp[numpractrials],randp[numpractrials];
  int i,k;
  int rtwarnings=0;
  char stimstring[6];
  char blockstart[20];
  char feedback[50];

logtype *log;
FILE *outfile;
FILE *backfile;
char outline[80];
//long seed;
 int seed;


//images: fix, blank,target,answer
image *fix,*blank,*target,*answer;
//movie
movie *ques;
response *data;
 float RT;
 int resp,acc;
 double prand=.5;
 int randsign,randvalue;

//from si4

  UseDIO24= 0;
  log=(logtype *)malloc(1*sizeof(logtype));
  initLog(STATUS,log);
  outfile=fopen(log->outfn,"w");

  setup(800,600,800, 600, 0,rate,8,"../../fonts/fonts.lst"); 
  if(alfont_set_font_size(fontlst[1], 28)==ALFONT_ERROR)
    error("Cannot Set Font Size");
 
  seed=log->seed;
 
   makePalette(GRAYSCALE);

  ques=newMovie(3);
  fix=newImage();
  blank=newImage();
  target=newImage();
  
  for(i=0;i<numpractrials;i++)
    {
      letterp[i]=i+11;
      addentp[i]=((i%2))*2+7;
    }

  distribute(letterp,numpractrials,&seed);
  distribute(randp,numpractrials,&seed);


  for(k=0;k<numpracblocks;k++)
    {
      runMovieText("practice",xcen,ycen,1,255);

  for(i=0;i<numpractrials;i++)
  {  
 sum=letterp[i]+addentp[i];
 if(sum==27) {
  addentp[i]=7;
  sum=letterp[i]+addentp[i];}

 
  clearImage(fix);
  clearImage(blank); 


  vline(*fix,xcen,ycen+20,ycen-20,255);
  hline(*fix,xcen-20,ycen,xcen+20,255);

  setMovie(ques,0,fix,fixtime);
  setMovie(ques,1,blank,foretime);


  clearImage(target);
  
sprintf(stimstring,"%c+%d=?",numtolet(letterp[i]),addentp[i]);

   drawText(target,stimstring,xcen,ycen,1,253);
   setMovie(ques,2,target,1);
  data=runMovie(ques,UNTIL_RESPONSE,1);

 switch ((data)->x[0].resp & 0x00ff){  
 case 'F':resp=6 ;break;
 case 'f':resp=6 ;break;
 case 'G':resp=7 ;break;
 case 'g':resp=7 ;break;
 case 'H':resp=8 ;break;
 case 'h':resp=8 ;break;
 case 'I':resp=9 ;break;
 case 'i':resp=9 ;break;
 case 'J':resp=10 ;break;
 case 'j':resp=10 ;break;
 case 'K':resp=11 ;break;
 case 'k':resp=11 ;break;
 case 'L':resp=12 ;break;
 case 'l':resp=12 ;break;
 case 'M':resp=13 ;break;
 case 'm':resp=13 ;break;
 case 'N':resp=14 ;break;
 case 'n':resp=14 ;break;
 case 'O':resp=15 ;break;
 case 'o':resp=15 ;break;
 case 'P':resp=16 ;break;
 case 'p':resp=16 ;break;
 case 'Q':resp=17 ;break;
 case 'q':resp=17 ;break;
 case 'R':resp=18 ;break;
 case 'r':resp=18 ;break;
 case 'S':resp=19 ;break;
 case 's':resp=19 ;break;
 case 'T':resp=20 ;break;
 case 't':resp=20 ;break;
 case 'U':resp=21 ;break;
 case 'u':resp=21 ;break;
 case 'V':resp=22 ;break;
 case 'v':resp=22 ;break;
 case 'W':resp=23 ;break;
 case 'w':resp=23 ;break;
 case 'X':resp=24 ;break;
 case 'x':resp=24 ;break;
 case 'Y':resp=25 ;break;
 case 'y':resp=25 ;break;
 case 'Z':resp=26 ;break;
 case 'z':resp=26 ;break;

  case '@': resp=4;break;
   default: resp=5;break;}

 
  if (resp==4) {cleanup();
  printf ("stopped while running by participant\n");exit(1);}
  
  
  
   if ((ques->x[2].ts)==0) RT=-1; //*RT or RT?
  else  RT=((data)->x[0].rt-ques->x[2].ts)*rtSlope;
  
  if (RT<.2)
    {
      audio(ERROR);
      runMovieTimedText("TOO FAST! WAIT TO CONTINUE",xcen,ycen,1,255,360);
            sprintf(feedback,"%c+%d=%c.",numtolet(letterp[i]),addentp[i],numtolet(letterp[i]+addentp[i]));
            runMovieTimedText(feedback, xcen,ycen-40,1,255,60);
    }

  
  if (resp==5 && RT>=.2)
    {
      runMovieText("INVALID KEY <reposition hands, hit spacebar to continue>",xcen,ycen,1,255);
    }
  

 
      if(resp==sum) acc=1;
      else acc=0;

   
        
      if(acc==1) audio(CORRECT);
	  else 
	    { 
	      if(RT>=.2){
	    audio(ERROR);
  //runMovieTimedText("Incorrect", xcen,ycen-40,1,255,120);
            sprintf(feedback,"%c+%d=%c.",numtolet(letterp[i]),addentp[i],numtolet(letterp[i]+addentp[i]));
            runMovieTimedText("incorrect", xcen,ycen-40,1,255,240);
            runMovieTimedText(feedback, xcen,ycen-40,1,255,60);
	      }
          };    

 
  fprintf(outfile,"%03d -%02d %02d    %d %c %d   %d %d %d  %c %d %lf\n",
log->subjnum,k,i,letterp[i],numtolet(letterp[i]),addentp[i],randp[i],sum,resp,numtolet(resp),acc,RT);
  }
    
}

	 // random number generation
  
  for(i=0;i<numtrials;i++)
    {
     letter[i]=i+1;
     addent[i]=((i%2))*2+7;
     //ax[i]=i;
    }
  
  //distribute(letter,numtrials,&seed);
  //distribute(rand,numtrials,&seed);

  for(i=0;i<(numtrials/2);i++)
    {
      ax1[i]=i;
    }

  for(i=0;i<(numtrials/2);i++)
    {
      ax2[i]=i;
    }

  for(k=0;k<numblocks;k++)
    {
      if(k==0) runMovieText("the first block",xcen,ycen,1,255);
      else {sprintf(blockstart,"Repetition %d",k);
      runMovieText(blockstart,xcen,ycen,1,255);}
      // runMovieText("A new block",xcen,ycen,1,255);
  distribute(ax1,(numtrials/2),&seed);
  distribute(ax2,(numtrials/2),&seed);

  for(i=0;i<(numtrials/2);i++)
    {
      ax[i]=ax1[i];
    }
    for(i=(numtrials/2);i<numtrials;i++)
      {
	ax[i]=5+ax2[i-(numtrials/2)];
	  }

  for(i=0;i<numtrials;i++)
  {  
   sum=letter[ax[i]]+addent[ax[i]];
 
  clearImage(fix);
  clearImage(blank); 


  vline(*fix,xcen,ycen+20,ycen-20,255);
  hline(*fix,xcen-20,ycen,xcen+20,255);

  setMovie(ques,0,fix,fixtime);
  setMovie(ques,1,blank,foretime);


  clearImage(target);
  ///sprintf(stimstring,"%d+%d=%d",letter[ax[i]],addent[ax[i]],sum);
sprintf(stimstring,"%c+%d=?",numtolet(letter[ax[i]]),addent[ax[i]]);

   //        sprintf(stimstring,"%c+%i=%c",
   //             (char)(numtolet(getletter(alltrials[ax[i]]))), getaddend(alltrials[ax[i]]), (char)(numtolet(getsum(alltrials[ax[i]])))    );

   //runMovieText(stimstring,xcen,ycen,0,255);
   drawText(target,stimstring,xcen,ycen,1,253);
   setMovie(ques,2,target,1);
  data=runMovie(ques,UNTIL_RESPONSE,1);

  
  
 switch ((data)->x[0].resp & 0x00ff){ 
 case 'F':resp=6 ;break;
 case 'f':resp=6 ;break;
 case 'G':resp=7 ;break;
 case 'g':resp=7 ;break;
 case 'H':resp=8 ;break;
 case 'h':resp=8 ;break;
 case 'I':resp=9 ;break;
 case 'i':resp=9 ;break;
 case 'J':resp=10 ;break;
 case 'j':resp=10 ;break;
 case 'K':resp=11 ;break;
 case 'k':resp=11 ;break;
 case 'L':resp=12 ;break;
 case 'l':resp=12 ;break;
 case 'M':resp=13 ;break;
 case 'm':resp=13 ;break;
 case 'N':resp=14 ;break;
 case 'n':resp=14 ;break;
 case 'O':resp=15 ;break;
 case 'o':resp=15 ;break;
 case 'P':resp=16 ;break;
 case 'p':resp=16 ;break;
 case 'Q':resp=17 ;break;
 case 'q':resp=17 ;break;
 case 'R':resp=18 ;break;
 case 'r':resp=18 ;break;
 case 'S':resp=19 ;break;
 case 's':resp=19 ;break;
 case 'T':resp=20 ;break;
 case 't':resp=20 ;break;
 case 'U':resp=21 ;break;
 case 'u':resp=21 ;break;
 case 'V':resp=22 ;break;
 case 'v':resp=22 ;break;
 case 'W':resp=23 ;break;
 case 'w':resp=23 ;break;
 case 'X':resp=24 ;break;
 case 'x':resp=24 ;break;
 case 'Y':resp=25 ;break;
 case 'y':resp=25 ;break;
 case 'Z':resp=26 ;break;
 case 'z':resp=26 ;break;

  case '@': resp=4;break;
   default: resp=5;break;}

 
  if (resp==4) {cleanup();
  printf ("stopped while running by participant\n");exit(1);}
  
  
  
   if ((ques->x[2].ts)==0) RT=-1;
  else  RT=((data)->x[0].rt-ques->x[2].ts)*rtSlope;
  
  if (RT<.2)
    {
      audio(ERROR);
      runMovieTimedText("TOO FAST! WAIT TO CONTINUE",xcen,ycen,1,255,360);
            sprintf(feedback,"%c+%d=%c.",numtolet(letter[ax[i]]),addent[ax[i]],numtolet(letter[ax[i]]+addent[ax[i]]));
            runMovieTimedText(feedback, xcen,ycen-40,1,255,60);
    }

  
  if (resp==5 && RT>=.2)
    {
      runMovieText("INVALID KEY <reposition hands, hit spacebar to continue>",xcen,ycen,1,255);
    }
  
  if(resp==(letter[ax[i]]+addent[ax[i]])) acc=1;
  else acc=0;
    
    
      if(acc==1) audio(CORRECT);
      else          
          {
	    if(RT>=.2)
	      {
	    audio(ERROR);
            sprintf(feedback,"%c+%d=%c.",numtolet(letter[ax[i]]),addent[ax[i]],numtolet(letter[ax[i]]+addent[ax[i]]));
            runMovieTimedText("incorrect", xcen,ycen-40,1,255,240);
            runMovieTimedText(feedback, xcen,ycen-40,1,255,60);
	      }
          };     

   

  fprintf(outfile,"%03d %02d %02d   %d %c %d %d %d %d  %c %d %lf\n", 
    log->subjnum,k,i,  letter[ax[i]],numtolet(letter[ax[i]]),addent[ax[i]],rand[ax[i]],sum,resp,numtolet(resp),acc,RT);
  }
    
}


 
fclose(outfile);
//runMovieText(ques->x[2].ts,xcen,ycen,1,255);
  runMovieText("STOP!!! Go back to room 203",xcen,ycen,1,255);
  cleanup();
  
}


int getaddend(int id){
  return 1; //(id%numaddends)+1;
}

int getsum(int id){
 //int temp=floor(floor(id/numaddends)/numletters);
 return 1; //(temp%numsums)+sumone+getletter(id)+getaddend(id);
}

int getletter(int id){
 //int temp=floor(id/numaddends);
 return 1; //(temp%numletters)+1;
}

int numtolet(int id){
return (id+64);
}
