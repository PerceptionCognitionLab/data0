#! usr/bin/perl

#####################################
# DMDX item file generator          #
# Richard Morey                     #
# University of Missouri - Columbia #
# 2002                              #
#####################################

#experiment aa0
$experimentname="aa0b";

($firstsubjectnumber, $numsubjects, $baseseed)=@ARGV;

if ((@ARGV[0] eq '') or (lc(@ARGV[0]) eq 'help')){
    print "\nUsage:\n\n";
    print "perl $experimentname firstsubjectnumber numberofsubjects baserandomseed\n\n";
    end;
}


for ($subjectnumber=$firstsubjectnumber;$subjectnumber<=$numsubjects+$firstsubjectnumber-1;$subjectnumber++){

#remember: DOS newlines are In text files, "\n" eq "\015\012" 
#in Unix, \n eq "\012"
#use strict;
($sec,$min,$hour,$mday,$mon,$year,$wday,$yday) = gmtime(time);
$houroffset=-5;  

#User editable sections: Parameters, Experiement stuff - scroll down to edit

#Begin parameters

#Resolutions:
#1 : 320x200
#2 : 640x480
#3 : 800x600
#4 : 1024x768
#5 : 1280x960
#6 : 1600x1200

#Color depths:
#1 : Black and white
#2 : 256 color (8bpp)
#3 : 65536 color (16 bpp)
#4 : 16.7 mill colors (24bpp)
#5 : 4.3 bill colors (32bpp)

$screenres           = 2;
$colordepth          = 3;
$fontcolor           = 255255000;  #for colors, use 255255255 for white, 
$backgroundcolor     = 000000153;  #000000000 for black (RGB triplet)
$fillcolor           = 000000153;
$fontname            = "Courier New";

$usekeyboard         = 1;
$usepiocard          = 0;
$usemouse            = 0;

$frameduration       = 0; #in ticks
$timeforresponse     = 20000;   #in milliseconds (0 to disable)
$delaybetweentrials  = 15;   #in ticks (if -1, it will not specify)

$continuousrun       = 1;   #Don't wait for subject to request next item
$nofeedback          = 1;
$correctfeedbackonly = 0;
$wrongfeedbackonly   = 0;
$clearfeedback       = 0;   #<SEEMS BROKEN>Clear the screen after response
$feedbacktimedisplay = 0; 
$feedbackduration    = 0;   #in ticks


$usezillion          = 0;
$zilliononeresponse  = 0;
$zillionresponses    = 0;
$usetimedbreaks      = 1;
$ticklength          = 13.3; #in milliseconds



$readybeep           = "ready.wav";
$wavpan=2;		        #0:left, 1:right, 2:both


#Get user input
#print "Subject number:\n";
#chomp($subjectnumber=<STDIN>);
#print "Seed [0]:\n";
#chomp($randomseed=<STDIN>);

#####end parameters
$filename=$experimentname."s".$subjectnumber;

$outfile=$filename.".out";
$filename.=".rtf";

open OUTFILE,  ">$outfile" or die "Cannot open $outfile for write :$!";
open ITEMFILE, ">$filename" or die "Cannot open $filename for write :$!";
#print "Outfile: $outfile\nItemfile: $filename\n";


#####Experiment stuff
@openingmessages=(
			"Good luck! If you have any questions, ask now.",
		  	"Ready?"
		  		 ); #add more messages, inside quotes and comma deliniated. 


@endingmessages=(
                  "Thanks for participating. Please see the experimenter.",
		  "END."							
                                    );#add more messages, inside quotes and comma deliniated


$numberofopeningmessages=$#openingmessages+1;
$numberofendingmessages =$#endingmessages+1;

#Stimuli type
#0=text
#1=Bitmap (picture)
#2=Wavetable file (sound)

$stimulitype=0;
$randomseed=0 if ($randomseed eq '');
$positiveresponse="+z";
$negativeresponse="+/";


$bmpjustification     = 1;   #0 = left, 1 = center, 2 = right
#####End Experiment stuff
#####Begin RTF formatting

$RTFdataline = "{\\rtf1\\ansi\\ansicpg1252\\deff0\\deflang1033{\\fonttbl{\\f0\\fnil\\fcharset0 ".$fontname.";}}\n"; 
$newparagraph= "\n\\pard\\f0\\fs20\\par\n";
$firstparagraph= "\n\\pard\\f0\\fs20";

#####end RTF formatting


	$parameterline=&createparameterline;	
	
	
#	print "\nPrinting parameters to file....\n";
	print ITEMFILE $parameterline;
        print ITEMFILE $newparagraph;
	
#	print "Printing opening to file....\n";
	print ITEMFILE $opening;
	
#	print "Printing experiment body to file....\n";
	$experimentcounter=&createexperiment;
	print "$experimentcounter items written.\n";
	
#	print "Printing ending to file....\n";
#	print "\n$numberofendingmessages\n";
	
close OUTFILE;
close ITEMFILE;

}
end;





###begin subroutines

sub createparameterline {
#	print "Building parameter line....\n";
	$filesofar=$RTFdataline.$firstparagraph;
	
	#Output video mode and color depth
	$filesofar.="<VideoMode ".&getvideomode($screenres, $colordepth).">";
	
	$filesofar.="<cr>" if ($continuousrun);
	$filesofar.="<NoFeedBack>" if ($nofeedback);
	$filesofar.="<CorrectFeedbackOnly>" if ($correctfeedbackonly);
	$filesofar.="<WrongFeedbackOnly>" if ($wrongfeedbackonly);
	$filesofar.="<ClearFeedback>" if ($clearfeedback);
	$filesofar.="<NoFeedbackTime>" if (!$feedbacktimedisplay);
	$filesofar.="<Delay ".$delaybetweentrials.">";
	$filesofar.="<DefaultFrameDuration ".$frameduration.">";
	$filesofar.="<DefaultBackgroundColor ".$backgroundcolor.">";
	$filesofar.="<DefaultWritingColor ".$fontcolor.">";
	if ($timeforresponse){ $filesofar.="<Timeout ".$timeforresponse.">";}
		else{ $filesofar.="<NoTimeLimit>";}
	$filesofar.="<id keyboard>" if $usekeyboard;
	$filesofar.="<id mouse>" if $usemouse;
	$filesofar.="<id pio12>" if $usepiocard;
	if ($usezillion) {
		$filesofar.="<Zillion ".$zillionresponses.">";
		$filesofar.="<ZillionOneResponse>" if ($zillionresponses);
	}

	$filesofar.="\n";	
	return $filesofar;
}
			

sub getvideomode {
	my ($modenumber, $colornumber)=@_;
	my $vmline="";	

	$videomode = "320,240,240," if ($modenumber==1);	
	$videomode = "640,480,480," if ($modenumber==2);	
	$videomode = "800,600,600," if ($modenumber==3);	
	$videomode = "1024,768,768," if ($modenumber==4);	
	$videomode = "1280,960,960," if ($modenumber == 5);	
	$videomode = "1600,1200,1200," if ($modenumber == 6);	
	
	$colors = "1,0" if ($colornumber==1);
	$colors = "8,0" if ($colornumber==2);
	$colors = "16,0" if ($colornumber==3);
	$colors = "24,0" if ($colornumber==4);
        $colors = "32,0" if ($colornumber==5);

	$vmline = $videomode.$colors;
	return $vmline;

}

sub createopening {
	for ($i=0;$i<=($numberofopeningmessages-1);$i++) {
		$openinglines.="0 \"".$openingmessages[$i]."\";\n";
	}
	return $openinglines;
}

sub createending {
	for ($i=0;$i<=($numberofendingmessages-1);$i++) {
	        $endinglines.="0 \"".$endingmessages[$i]."\";\n";
	}
	$endinglines.="\n\\par\n}";
	return $endinglines;
}


sub createexperiment {

    $experimentcounter=0;
$opening=&createopening;
$ending=&createending;
print ITEMFILE "1 <bu 1000>;\n\n";


$wrongmedia="wrong.wav";
$correctmedia="correct.wav";
$alphabet="ABCDEFGHIJKLMNOPQRSTUVWXYZ";
@letters=("A","B","C","D","E","F","G","H");
@numbers=(1,2,3,4,5);
@answers=(-1,0,1);
$numrepeated=10;
$timestorepeat=20;
@repeated=();
@stimulitrue=();
@stimulifalse=();
@finalset=();
    @list=();
srand($baseseed+$subjectnumber);


#create feedback
print ITEMFILE "11 d2 <biw 31> c;\n";
print ITEMFILE "21 <wav $wavpan> \"$correctmedia\"<return>;\n";
print ITEMFILE "31 <wav $wavpan> \"$wrongmedia\"<return>;\n\n";
########################

print ITEMFILE "1000;\n$opening";


for ($i=0;$i<=$#letters;$i++){
    for ($j=0;$j<=$#numbers;$j++){
	for ($k=0;$k<=$#answers;$k++){
	    $stimulus="$letters[$i]+$numbers[$j]=";
	    $answer=substr($alphabet, (index($alphabet,$letters[$i])+$numbers[$j]+@answers[$k]), 1);
	    if ($k==1) {push(@stimulitrue,$stimulus.$answer);}else{push(@stimulifalse,$stimulus.$answer);}	    
	}
    }
}


    @incorrectselection=(-1,-1,1,1,$answers[2*int(rand(2))]);
for ($i=1;$i<=$numrepeated;$i++){
	
	if ($i<=int($numrepeated/2)){
		@numberstemp=@numbers;
		$l=int(rand($#letters+1));
		push(@repeated,"$letters[$l]+$i=".(substr($alphabet, (index($alphabet,$letters[$l])+$numbers[$i-1]), 1))     );
		}else{
		@numberstemp=@numbers;
                $l=int(rand($#letters+1));
                #$m=2*int(rand(2));
		#print "$m\n";
		push (@repeated,"$letters[$l]+".($i-5)."=".(substr($alphabet, (index($alphabet,$letters[$l])+$numbers[$i-6]+splice(@incorrectselection, rand @incorrectselection,1)), 1)));
		#print @repeated[-1]."\n";
	    }

push(@finalset,($repeated[$i-1]) x $timestorepeat);
}

$counter=0;
$countermax=$#stimulitrue;
for ($counter=0;$counter<=$countermax;$counter++){
    $item2=$stimulitrue[$counter];
    foreach $item (@repeated){
	    
	if ($item2 eq $item){ 
	    splice(@stimulitrue,$counter,1); 
#	    print "Got it! $stimulitrue[$counter] $counter\n";
	    $counter--; 
	    
	}
#	print "$item  $item2  ".(($item2 eq $item)+0)." $stimulitrue[$counter] $counter\n";
	
    }
 
}


$counter=0;
$countermax=$#stimulifalse;
for ($counter=0;$counter<=$countermax;$counter++){
    $item2=$stimulifalse[$counter];
    foreach $item (@repeated){
	    
	if ($item2 eq $item){ 
	    splice(@stimulifalse,$counter,1); 
#	    print "Got it! $stimulitrue[$counter] $counter\n";
	    $counter--; 
	    
	}
#	print "$item  $item2  ".(($item2 eq $item)+0)." $stimulifalse[$counter] $counter\n";
	
    }
 
}



#for ($i=0;$i<=$#stimulifalse;$i++){ 
#        foreach $item (@repeated){                   
#        splice(@stimulifalse,$i,1) if ($stimulifalse[$i] eq $item);                                   
#        print "$item  $stimulifalse[$i]  ".(($stimulifalse[$i] eq $item)+0)."\n";
#    }                                             
#}

#print "repeated: $#repeated --- @repeated\n\n";
#print "stimulitrue: $#stimulitrue --- @stimulitrue\n\n";
#print "stimulifalse: $#stimulifalse --- @stimulifalse\n\n";


#for ($i=1;$i<=$numrepeated;$i++){
#    if ($i<=int($numrepeated/2)){
#	$rndrepeated=splice(@stimulitrue,int(rand($#stimulitrue+1)),1);
#	}else{
#    	$rndrepeated=splice(@stimulifalse,int(rand($#stimulifalse+1)),1);
#	}
#	push(@repeats,$rndrepeated);
#    push(@finalset,($rndrepeated) x $timestorepeat);
#}


push(@finalset,@stimulitrue,@stimulifalse);


push(@list, splice(@finalset, rand @finalset, 1)) while @finalset;
@finalset=@list;

for ($i=1;$i<=($#finalset+1);$i++){
    $experimentcounter++;
    $letter=substr($finalset[$i-1],0,1);
    $number=substr($finalset[$i-1],2,1);
    $answer=substr($finalset[$i-1],-1,1);
    if ((index($alphabet,$letter)+$number)==index($alphabet,$answer)){$correct="+";}else{$correct="-";}
    $lineitem=$correct.($i+1000)." <umpr><umnr><mpr $positiveresponse><mnr $negativeresponse>*\"$finalset[$i-1]\" <Call -11>;\n";
    print ITEMFILE $lineitem;
    
    $repeat=0;
    foreach $test (@repeated){
	$repeat=($test eq $finalset[$i-1]) if (!$repeat);
	$repeat=0 if (!$repeat);
    }	
    if ($correct eq "+"){$correctnum="1";}else{$correctnum="0";}
    print OUTFILE join(' ', $i, $correctnum, $repeat, $letter, $number, $answer)."\n";
}

print ITEMFILE $ending;
print "Done: Subject $subjectnumber, seed ".($baseseed+$subjectnumber)." ...."; 
return $experimentcounter;
}
sub digitbase36{
	my $digit;
	($digit)=@_;
	my $mapdigits = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ";
	return index($mapdigits,$digit);
 
}

sub randomdigit{
	my $max;
	my $min;
	($min, $max)=@_;
	return (int(rand(1)*($max-$min+1))+$min);
	
}














