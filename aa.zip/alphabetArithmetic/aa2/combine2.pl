#! usr/bin/perl

$subjectline="Subjects incorp";
$itemline="Item";

($filename)=@ARGV;

$dosnewline=chr(13).chr(10);
$outfile="$filename".".out";
$zilfile="$filename".".azk";
$datfile="$filename".".dat";

open OUTFILE, $outfile or die "Could not open $outfile for read.";
open ZILFILE, $zilfile or die "Could not open $zilfile for read.";
open DATFILE, ">$datfile" or die "Could not open $datfile for write.";
$firsttrial=-1;

while (<OUTFILE>){
#	$_=~s/$dosnewline//g;
	chomp($_);
	($trialnum,$true,$repeat,$letter,$number,$answer)=split(/ /,$_);
	$trialnum+=1000;
	$firsttrial=$trialnum if ($firsttrial==-1);
#	push(@finalarray,join(',',$true,$repeat,$letter,$number,$answer));		
	$finalarray[$trialnum]=join(',',$true,$repeat,$letter,$number,$answer);
	
}
print "Firsttrial: $firsttrial\n";
while (<ZILFILE>){
	$_=~s/$dosnewline//g;
	if ($_=~/$subjectline/){
		($garbage,$subjectsinc)=split(/:/,$_);
		die "More than one subjects are included in $zilfile. Quitting...\n" if (($subjectsinc+1)>2);
	}
	print "$_\n";
	if (substr($_,0,1) ne '!'){
	if (!($_=~/$itemline/)){
		#$_=(<ZILFILE>);
		$_=~s/$dosnewline//g;
		$_=substr($_,2);
		print "$_\n";
		($trialnum,$subjectcorrect)=split(/ +/,$_);
		$subjectcorrect2=substr($subjectcorrect,0,1);
		if ($subjectcorrect2 eq '-'){
			$iscorrect=0;
			}else{
			$iscorrect=1;
		}
		$finalarray[$trialnum].=",$iscorrect";
		($true,$repeat,$letter,$number,$answer,$iscorrect)=split(/,/,$finalarray[$trialnum]);
		
		$finalarray[$trialnum]="t$true r$repeat $iscorrect l$letter a$number s$answer";
		}
	}

}

#print DATFILE 
"*ITEM#,SUBANS,CORANS,ISCORR,ACTANS,SGRP,INBREAK,INWARN,SWITCH,OTHER,TTYPE,SEED,RTIME\n";
for ($i=$firsttrial;$i<=$#finalarray;$i++){
	$l++;
	print DATFILE sprintf("%04d",($i-$firsttrial+1))." $finalarray[$i]\n";
#	print DATFILE $breaks[$i];
}
print "Output $l items to $datfile.\n\n";



close OUTFILE;
close ZILFILE;
close DATFILE;



