#include <stdio.h>       
#include <stdlib.h>
#include <string.h> /*for memcpy command*/
#include "movieobj.h"
#include "video.h"
#include <mem.h>
#include "exptlib.h"
#include <math.h>

#define status STAND_ALONE
#define numletters 8
#define numaddends 5
#define numsums 3
#define WRONG 0
#define RIGHT 1
#define resptrue "z"
#define respfalse "/"
#define numrepeated 10
#define numreps 20
#define numnoveltrials ((numletters*numaddends*numsums)-numrepeated)
#define numreptrials (numrepeated*numreps)
#define numtrials numnoveltrials+numreptrials
#define numstimuli (numletters*numaddends*numsums)
#define sumone 1-(floor(numsums/2)+1)

int checkrepeated(int repeated[], int length);
char * convertid(int id);
int testtrue(int id);
int testrepeat(int id, int repeats[]);
int getaddend(int id);
int getletter(int id);
int getsum(int id);

int main(){
 
 //long seed=0;
 int allstim[numstimuli];
 int i=0;
 int repeatedstimuli[numrepeated];
 int novelstimuli[numnoveltrials];
 int reptrials[numreptrials];
 int alltrials[numtrials];
 char *stimulus;
 char stimstring[5];
 int stimcounter[numstimuli];  

  // Jeff's stuff
  logtype *log;
  FILE *outfile,*backfile;
  char *fontlist,junk[3];
  char backstr[40],outline[80];
  long seed;

  image *wrong_i,*blank, *targ_i;
  movie *wrong_m,*ready_m,*stim_m,*feed_m;
  image *ready13_i;
  response *data,*data2; int resp,second; long RT;

  fontlist=getenv("FONTLIST");
  log=(logtype *)malloc(1*sizeof(logtype));
  gen_init(status,log);
//SetupMoviePackage(fontlist);
  seed=log->seed;
  outfile=fopen(log->outfn,"wt");
  //end Jeff's stuff
 
 
 for (i=0;i<numrepeated;i++) repeatedstimuli[i]=0; //initializing to 0s
 for (i=0;i<numstimuli;i++) stimcounter[i]=0; //initializing to 0s
 
 for (i=0;i<numstimuli;i++){
        allstim[i]=i;        //creating all stimuli
 }
 
 //the next loop picks the repeated and novel, and checks to make sure
 //each addend is picked evenly for the repeated
 
 while (!(checkrepeated(repeatedstimuli,numrepeated))){
        distribute(allstim,numstimuli,&seed);
        for (i=0;i<numstimuli;i++){
         if (i<numrepeated){
                 repeatedstimuli[i]=allstim[i];
         }else{
                 novelstimuli[i-numrepeated]=allstim[i];
         }
        }
 
 }
 //repeat the repeated trials
 for (i=0;i<numreptrials;i++) reptrials[i]=repeatedstimuli[i%numrepeated];
 
 //add all trials to the mix and distribute
 for (i=0;i<numtrials;i++){
        if (i<numreptrials) {
                alltrials[i]=reptrials[i];
        }else{
                alltrials[i]=novelstimuli[i-numreptrials];
        }
 }
 distribute(alltrials,numtrials, &seed);

 
 //start running trials
 for (i=0;i<numtrials;i++){
        stimulus=convertid(alltrials[i]);
        sprintf(stimstring,"%c%c%c%c%c",
              stimulus[0],stimulus[1],stimulus[2],stimulus[3],stimulus[4]);
 stimcounter[i]++; 
// sprintf(outline, "sub%03d trl%03d let%i add%i sum%i tru%i rep%i rsp%i cor%i %05d",
//       log->subjnum, i, getletter(alltrials[i]), getaddend(alltrials[i]),
//       getsum(alltrials[i]), testtrue(alltrials[i]), stimcounter[i],)
//fprintf(outfile,"%s",outline);  
 }

 //cleanup
 fclose(outfile);
 //thankyou();
 //CleanupMoviePackage();
 return 0;
}

int checkrepeated(int repeated[], int length){
 int numaddendsused[numaddends*2];
 int i=0;
 int problem=0; 

 for (i=0;i<(numaddends*2);i++) numaddendsused[i]=0;
 
 for (i=0;i<length;i++) 
        if(testtrue(repeated[i])){
                numaddendsused[repeated[i]%numaddends]++;
        }else{
                numaddendsused[(repeated[i]%numaddends)+numaddends]++;
        }
 for (i=0;i<(numaddends*2);i++)
        if (numaddendsused[i]!=((numrepeated/numaddends))/2) problem=1;

 
 if (problem) {return 0;} else{return 1;}
}


char * convertid(int id){
 char stimulus[]="L+N=S";
 int addend;
 int temp;
 int letter;
 int sum;
 char charletter;
 char charsum; 
 addend=(id%numaddends)+1;
 temp=floor(id/numaddends);
 letter=(temp%numletters)+1;
 temp=floor(floor(id/numaddends)/numletters);
 sum=(temp%numsums)+sumone;
 charletter=(letter+64);
 charsum=(letter+addend+sum+64);
 sprintf(stimulus,"%c+%i=%c",charletter,addend,charsum);
 return stimulus;
}

int testtrue(int id){
 int temp=floor(floor(id/numaddends)/numletters);
 int sum=(temp%numsums)+sumone;
 return (!(sum));
}

int testrepeat(int id, int repeats[]){
 int problem=0;
 int i;
 for (i=0;i<numrepeated;i++) if (id==repeats[i]) problem=1;
 return problem;
}

int getaddend(int id){
 return (id%numaddends)+1;
}

int getsum(int id){
 int temp=floor(floor(id/numaddends)/numletters);
 return (temp%numsums)+sumone+getletter(id)+getaddend(id);
}

int getletter(int id){
 int temp=floor(id/numaddends);
 return (temp%numletters)+1;
}
